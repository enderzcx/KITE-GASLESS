﻿param(
  [string]$BaseUrl = "http://localhost:3001",
  [Parameter(Mandatory=$true)][string]$Payer,
  [string]$SourceAgentId = "1",
  [string]$TargetAgentId = "2",
  [Parameter(Mandatory=$true)][string]$Symbol,
  [Parameter(Mandatory=$true)][double]$TakeProfit,
  [Parameter(Mandatory=$true)][double]$StopLoss
)

$payload = @{
  payer = $Payer
  sourceAgentId = $SourceAgentId
  targetAgentId = $TargetAgentId
  task = @{
    symbol = $Symbol
    takeProfit = $TakeProfit
    stopLoss = $StopLoss
  }
}

Invoke-RestMethod -Method Post -Uri "$BaseUrl/api/skill/openclaw/invoke" -ContentType "application/json" -Body ($payload | ConvertTo-Json -Depth 8)
